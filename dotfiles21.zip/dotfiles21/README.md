# dotfiles21
New dotfiles, a fresh start (with GNU Stow?)
